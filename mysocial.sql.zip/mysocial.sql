-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2021 at 11:41 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mysocial`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(19) NOT NULL,
  `postid` bigint(19) NOT NULL,
  `userid` bigint(19) NOT NULL,
  `post` text NOT NULL,
  `image` varchar(500) NOT NULL,
  `comments` int(11) NOT NULL,
  `likes` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `has_image` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `postid`, `userid`, `post`, `image`, `comments`, `likes`, `date`, `has_image`) VALUES
(1, 29302483267, 29034884547676011, 'ssssss', '', 0, 0, '2021-10-02 11:44:49', 0),
(2, 625116850531, 29034884547676011, 'This is so cool! This is so cool! This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!This is so cool!', '', 0, 0, '2021-10-02 11:45:40', 0),
(3, 895694, 29034884547676011, 'This is my fairy tale', '', 0, 0, '2021-10-02 12:02:50', 0),
(4, 1568, 29034884547676011, 'This is my fairy tale', '', 0, 0, '2021-10-02 12:03:05', 0),
(5, 95865170738, 29034884547676011, 'This is my correction', '', 0, 0, '2021-10-02 12:06:07', 0),
(6, 9223372036854775807, 565412418256094, 'Hi this is my first great programming work ever', '', 0, 0, '2021-10-02 12:42:48', 0),
(7, 92434098490377, 29152478398, 'Helloooooooo!!!\r\n', '', 0, 0, '2021-10-02 12:56:04', 0),
(8, 929102049, 29152478398, 'You are awesomely created by Almighty God.\r\n\r\nAlpha Omega, Beginning and the End, First and Last!', '', 0, 0, '2021-10-13 11:07:28', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(19) NOT NULL,
  `userid` bigint(19) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `url_address` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `profile_image` varchar(1000) NOT NULL,
  `cover_image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userid`, `first_name`, `last_name`, `gender`, `email`, `password`, `url_address`, `date`, `profile_image`, `cover_image`) VALUES
(16, 23107, 'Tobo', 'Nero', 'Male', 'tobo1@gmail.com', '12', 'tobo.nero', '2021-10-01 23:43:19', '', ''),
(17, 29034884547676011, 'Nero', 'Tobo', 'Male', 'tobo@gmail.com', '1234', 'nero.tobo', '2021-10-02 07:58:29', '', ''),
(18, 565412418256094, 'Samuel', 'Kenny', 'Male', 'sam@gmail.com', '1234', 'samuel.kenny', '2021-10-02 08:47:22', '', ''),
(19, 29152478398, 'Adeola', 'Abdul', 'Female', 'adeola@gmail.com', '1234', 'adeola.abdul', '2021-10-06 07:12:59', 'uploads/IMG_0109.JPG', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postid` (`postid`),
  ADD KEY `post_user_id` (`userid`),
  ADD KEY `likes` (`likes`),
  ADD KEY `date` (`date`),
  ADD KEY `comments` (`comments`),
  ADD KEY `has_image` (`has_image`);
ALTER TABLE `posts` ADD FULLTEXT KEY `post` (`post`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userid` (`userid`),
  ADD KEY `email` (`email`),
  ADD KEY `gender` (`gender`),
  ADD KEY `last_name` (`last_name`),
  ADD KEY `first_name` (`first_name`),
  ADD KEY `url_address` (`url_address`),
  ADD KEY `date` (`date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(19) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(19) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
